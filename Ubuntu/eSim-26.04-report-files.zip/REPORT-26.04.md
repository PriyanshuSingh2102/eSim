# eSim 2.5 – Ubuntu 26.04 Support Report

This report documents every problem faced while installing **eSim 2.5** and its dependency **NGHDL** on **Ubuntu 26.04 LTS**, the cause of each problem, and the fix that was applied. It follows the format of the existing `Ubuntu/REPORT.md` (Ubuntu 25.04 report) on the `installers` branch and adds the issues that report does not cover.

---

## 0. Test environment

| Item | Value |
| --- | --- |
| Host | Windows laptop, WSL2 (kernel `6.18.58.1-microsoft-standard-WSL2`) |
| Guest OS | Ubuntu **26.04.1 LTS** ("resolute"), 64-bit |
| eSim | `eSim-2.5.zip` from the eSim downloads page |
| Base script | `install-eSim-24.04.sh` (the closest script shipped in the zip) |
| Installed result | KiCad 9.0.8, GHDL 4.1.0 (LLVM 18.1.8 backend), ngspice-35 |

**Why 26.04 and not 25.04?** The task asks for "Ubuntu 25 and above". `wsl --list --online` on my machine lists only Ubuntu 22.04, 24.04 and 26.04, and the Ubuntu 25.04 (end-of-life) WSL image could not be downloaded (the download returned a 286-byte error page, and `wsl --import` failed with "Unrecognized archive format"). 26.04 is newer than 25.04, so it is within "Ubuntu 25 and above", and it triggers the same class of errors (newer LLVM, newer GCC, missing packages) plus a few more.

**Credit.** The `installers` branch already contains `install-eSim-25.04.sh` and a report covering three issues on 25.04 (LLVM 18, `llvm-config-18`, `libcanberra-gtk-module`). I hit the same three issues independently on 26.04 and applied the same fixes; they are listed below as problems 5 and 6 and marked as "already known". Problems 1–4 and 7–11 are new.

---

## 1. Summary

| # | Component | Problem | Fix | New? |
| --- | --- | --- | --- | --- |
| 1 | eSim | No installer script for Ubuntu 25.04 / 26.04 in the 2.5 zip | New `install-eSim-26.04.sh` and a `26.04` case in `install-eSim.sh` | yes |
| 2 | eSim / KiCad | KiCad 6.0 PPA returns `404` on 26.04, installer aborts | Skip the PPA, install KiCad from Ubuntu's own repository | yes |
| 3 | eSim / NGHDL | `unzip: command not found` | Install `unzip` (and `patch`) when missing | yes |
| 4 | NGHDL | `Unsupported Ubuntu version: 26.04` | Map 26.04 to the 24.04 NGHDL script | yes |
| 5 | NGHDL | `libcanberra-gtk-module` has no installation candidate | Install only `libcanberra-gtk3-module` | already known (25.04) |
| 6 | NGHDL | `Unhandled version llvm 21.1.8` while configuring GHDL | Use `llvm-18`, `clang-18`, `llvm-config-18` | already known (25.04) |
| 7 | NGHDL | ngspice build fails: `'bool' cannot be defined via 'typedef'` (GCC 15, C23) | Build with `CFLAGS="-std=gnu17"` | yes |
| 8 | eSim | `~/Desktop` does not exist, `cp` of `esim.desktop` aborts the install | `mkdir -p "$HOME/Desktop"` before the copy | yes |
| 9 | eSim / NGHDL | Re-running the installer fails on leftover root-owned build folders | Remove old `nghdl` and `~/nghdl-simulator` before unzipping | yes |
| 10 | eSim GUI | Welcome panel is blank (`welcome.html` not found) | Fix the base path in `src/browser/Welcome.py` | yes |
| 11 | eSim / KiCad 9 | Symbol libraries fail to load (`analog.lib ... not found`) | Install the table in `~/.config/kicad/9.0/` and drop stale Legacy entries | yes |

---

## 🔧 eSim installer

### 1. No installer script for Ubuntu 25.04 / 26.04

* **Issue:**
  The `install-eSim-scripts` folder of `eSim-2.5.zip` contains only three scripts, and `install-eSim.sh` rejects any other version.

  ```
  $ ls install-eSim-scripts
  install-eSim-22.04.sh  install-eSim-23.04.sh  install-eSim-24.04.sh
  ```
* **Fix:**
  Created `install-eSim-scripts/install-eSim-26.04.sh` (based on the repository's `install-eSim-25.04.sh`, with the fixes below) and added a `"26.04")` case to the version `case` in `install-eSim.sh`, next to the existing `"25.04")` case.

---

### 2. KiCad 6.0 PPA returns 404

* **Issue:**
  The script only knows 24.04 (and 25.04 in the repository). Any other release falls into the `else` branch and adds `ppa:kicad/kicad-6.0-releases`. That PPA has no packages for Ubuntu 26.04 ("resolute"), so `apt` fails and the installer aborts.

  ```
  Err:5 https://ppa.launchpadcontent.net/kicad/kicad-6.0-releases/ubuntu resolute Release
    404  Not Found [IP: 185.125.189.186 443]
  E: The repository 'https://ppa.launchpadcontent.net/kicad/kicad-6.0-releases/ubuntu resolute Release' does not have a Release file.

  Error! Kindly resolve above error(s) and try again.
  Aborting Installation...
  ```
  A failed run also leaves the broken PPA behind, so every later `apt update` fails until it is removed (`sudo add-apt-repository --remove ppa:kicad/kicad-6.0-releases`).
* **Cause:**
  Ubuntu 26.04 already ships KiCad (`apt-cache policy kicad` → candidate `9.0.8+dfsg-1`), so no PPA is needed.
* **Fix:**
  For 26.04 the script sets `kicadppa=""`, only adds a PPA when one is set, and installs the distribution packages without the `kicad=8.0.8+dfsg-1` pin used on 25.04:

  ```bash
  else
      kicadppa=""
  fi

  if [ -n "$kicadppa" ] && ! grep -q "^deb .*${kicadppa}" /etc/apt/sources.list /etc/apt/sources.list.d/* 2>/dev/null; then
      ...
  fi

  sudo apt-get install -y --no-install-recommends kicad kicad-footprints kicad-libraries kicad-symbols kicad-templates
  ```
  Result: `KiCad installation completed successfully!` (KiCad 9.0.8).
* **Known cosmetic issue:**
  On 26.04 the script prints "KiCad PPA is already present in sources." because the guard is false. It is harmless.

---

### 3. `unzip: command not found`

* **Issue:**
  The NGHDL step runs `unzip -o nghdl.zip`, but a minimal Ubuntu 26.04 image does not include `unzip`.

  ```
  Installing NGHDL...........................
  ./install-eSim-scripts/install-eSim-24.04.sh: line 66: unzip: command not found

  Error! Kindly resolve above error(s) and try again.
  Aborting Installation...
  ```
* **Fix:**
  Install `unzip` (and `patch`, used by fix 4–7) when missing, before the unzip:

  ```bash
  command -v unzip >/dev/null 2>&1 || sudo apt-get install -y unzip
  command -v patch >/dev/null 2>&1 || sudo apt-get install -y patch
  ```

---

### 8. `~/Desktop` does not exist

* **Issue:**
  The last step copies `esim.desktop` to `$HOME/Desktop/`. On a system without a `Desktop` folder (WSL, minimal installs) the copy fails and the whole install is reported as failed, even though everything else was installed.

  ```
  'esim-start.sh' -> '/usr/bin/esim'
  'esim.desktop' -> '/usr/share/applications/esim.desktop'
  'esim.desktop' -> '/home/userpriyashu123/Desktop/'
  cp: cannot create regular file '/home/userpriyashu123/Desktop/': Not a directory

  Error! Kindly resolve above error(s) and try again.
  Aborting Installation...
  ```
* **Fix:**
  Create the folder first:

  ```bash
  mkdir -p "$HOME/Desktop"
  cp -vp esim.desktop $HOME/Desktop/
  ```

---

### 9. Re-running the installer fails on leftover build folders

* **Issue:**
  After a failed or successful NGHDL run, the extracted `nghdl/ghdl-4.1.0` folder (and `~/nghdl-simulator`) contains files owned by root, because the NGHDL scripts use `sudo` for install steps. On the next run `mv` stops to ask for confirmation about overwriting a file the user cannot write to, an answer typed at that prompt does not help, and the GHDL build fails:

  ```
  mv grt/ghdl_main-tmp.ali grt/ghdl_main.ali
  mv: replace 'grt/ghdl_main.ali', overriding mode 0644 (rw-r--r--)?
  make: *** [src/grt/Makefile.inc:158: grt/run-bind.adb] Error 1

  Error! Kindly resolve above error(s) and try again.
  Aborting Installation...
  ```
* **Fix:**
  Remove the old folders before unzipping so every run starts clean:

  ```bash
  sudo rm -rf nghdl ~/nghdl-simulator
  unzip -o nghdl.zip
  ```

---

### 11. KiCad 9: symbol libraries fail to load

* **Issue:**
  After the install, opening **eSchema** in eSim (KiCad 9) first shows the first-run dialogs for the symbol and footprint tables, because the installer only creates `~/.config/kicad/6.0`. KiCad 9 reads `~/.config/kicad/9.0`. Choosing eSim's own table (`kicadLibrary/template/sym-lib-table`) then gives a Load Error:

  ```
  Errors loading symbols:
  Error loading symbol library analog.
  Library file '/usr/share/kicad/symbols/analog.lib' not found.
  Error loading symbol library analog_p.
  Library file '/usr/share/kicad/symbols/analog_p.lib' not found.
  Error loading symbol library breakout.
  Library file '/usr/share/kicad/symbols/breakout.lib' not found.
  ...
  ```
* **Cause:**
  The template table has **28 `Legacy` entries** (lines 222–249: `eSim_PSpice`, `abm`, `analog`, `analog_p`, `breakout`, `CONNECT`, `eval`, `marker`, `port`, `RAJ`, `source`, `sourcstm`, `special`, `VLAB`, `wizard` and the `LTspice_*` set) that point to old KiCad 5 `.lib` files. Those files exist neither in `kicadLibrary.tar.xz` nor in KiCad 9's symbol folder (only `eSim_Subckt.lib` exists). The modern eSim libraries (`eSim_Analog.kicad_sym`, `eSim_Devices.kicad_sym`, ...) were copied correctly to `/usr/share/kicad/symbols/`.
* **Fix:**
  The installer now also creates `~/.config/kicad/9.0`, copies the table there, and removes the Legacy entries:

  ```bash
  mkdir -p ~/.config/kicad/9.0
  cp kicadLibrary/template/sym-lib-table ~/.config/kicad/9.0/
  sed -i '/(type "Legacy")/d' ~/.config/kicad/9.0/sym-lib-table
  ```
  Result: the Load Error is gone and the symbol chooser opens with **720 items loaded** (screenshot 10).
* **Trade-off:**
  The eSim PSpice and LTspice legacy libraries are no longer listed; they would need converting to `.kicad_sym` to be used in KiCad 9.

---

## 🔧 NGHDL

### 4. `Unsupported Ubuntu version: 26.04`

* **Issue:**
  `nghdl/install-nghdl.sh` selects a script with a `case` that has only 22.04, 23.04 and 24.04:

  ```
  Detected Ubuntu Version: 26.04.1
  Unsupported Ubuntu version: 26.04 (26.04.1)
  ```
* **Fix:**
  Map 26.04 to the 24.04 NGHDL script:

  ```bash
  "24.04"|"26.04")
      SCRIPT="$SCRIPT_DIR/install-nghdl-24.04.sh"
      ;;
  ```
  Stored as `patches/fix1-version-case.patch` and applied by the eSim installer right after `unzip -o nghdl.zip`.

### 5. `libcanberra-gtk-module` has no installation candidate (already known from 25.04)

* **Issue:**
  ```
  Package 'libcanberra-gtk-module' has no installation candidate
  ```
* **Fix:**
  The GTK 2 module was dropped from Ubuntu; only the GTK 3 one remains. `install-nghdl-24.04.sh` line 68 changed from `sudo apt install -y libcanberra-gtk-module libcanberra-gtk3-module` to `sudo apt install -y libcanberra-gtk3-module`.

### 6. `Unhandled version llvm 21.1.8` (already known from 25.04, LLVM 20 there)

* **Issue:**
  GHDL 4.1.0's `configure` does not support LLVM 21, which is Ubuntu 26.04's default `llvm`:

  ```
  Build machine is: x86_64-linux-gnu
  Unhandled version llvm 21.1.8
  ```
* **Fix:**
  The script installed the default `llvm llvm-dev` and called `/usr/bin/llvm-config`. Ubuntu 26.04 still offers `llvm-17` to `llvm-22`, so:

  ```bash
  sudo apt install -y llvm-18 llvm-18-dev clang-18
  ./configure --with-llvm-config=/usr/bin/llvm-config-18
  ```
  Result: `Debugging is enabled with llvm 18.1.8`, and `ghdl --version` reports `GHDL 4.1.0 (tarball) [Dunoon edition] ... llvm 18.1.8 code generator`.

### 7. ngspice build fails with GCC 15 (C23)

* **Issue:**
  Ubuntu 26.04 ships GCC 15, which compiles C as C23 by default. In C23, `bool` is a keyword, but ngspice's `bool.h` still contains `typedef int bool;`:

  ```
  ../../../src/include/ngspice/bool.h:6:13: error: 'bool' cannot be defined via 'typedef'
      6 | typedef int bool;
  ../../../src/include/ngspice/bool.h:6:13: note: 'bool' is a keyword with '-std=c23' onwards
  make[2]: *** [Makefile:452: dstring.lo] Error 1
  ```
* **Fix:**
  Configure ngspice with the previous C standard (line 176 of `install-nghdl-24.04.sh`):

  ```bash
  CFLAGS="-std=gnu17 -O2 -g" ../configure --enable-xspice --disable-debug --prefix=$HOME/$nghdl/install_dir/ --exec-prefix=$HOME/$nghdl/install_dir/
  ```
  Result: ngspice builds and `ngspice --version` reports `ngspice-35`; the NGHDL installer ends with `NGHDL installed sucessfully`.
* **Harmless message:**
  `rm: cannot remove '/usr/bin/ngspice': No such file or directory` appears while the script removes an old soft link that does not exist yet.

NGHDL fixes 4–7 are stored as `patches/fix1-version-case.patch` and `patches/fix2-nghdl-script.patch`. They belong in the NGHDL project (`install-nghdl.sh` and `install-nghdl-24.04.sh`), because `nghdl.zip` is built from there; until then the eSim installer applies them after unzipping.

---

## 🔧 eSim GUI

### 10. Blank Welcome panel

* **Issue:**
  After the install, eSim starts but the Welcome panel is empty and the terminal prints:

  ```
  QTextBrowser: No document for file:///home/userpriyashu123/eSim-2.5/eSim-2.5/src/browser/library/browser/welcome.html
  ```
  (screenshot 01)
* **Cause:**
  `src/browser/Welcome.py` builds the path from the folder of the Python file (`src/browser`) instead of the eSim home folder, so it looks for `src/browser/library/browser/welcome.html`. The real file is `library/browser/welcome.html`. The code was written for the Windows executable layout (comment: "relative to the installed .exe location"). A temporary symbolic link confirmed the cause (screenshot 02).
* **Fix:**
  Go two folders up from `src/browser` for the non-frozen case (line 19):

  ```python
  base_path = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
  ```
  Result: the "About eSim" page shows (screenshot 03) and the terminal message is gone. This file is in the `master` branch (source code), not in the installer scripts.

---

## 2. Verification

| Check | Result |
| --- | --- |
| `lsb_release -a` | Ubuntu 26.04.1 LTS, codename resolute |
| `ghdl --version` | GHDL 4.1.0, llvm 18.1.8 code generator |
| `ngspice --version` | ngspice-35 |
| NGHDL installer | `NGHDL installed sucessfully`, soft links added |
| eSim starts | Main window opens, workspace `/home/userpriyashu123/eSim-Workspace` |
| NGHDL icon | "Ngspice Digital Model Creator (from VHDL)" opens (screenshot 04) |
| KiCad to Ngspice icon | Asks to select a project first (normal eSim behaviour, screenshot 05) |
| Open eSchema | KiCad 9 schematic editor opens (screenshot 08) |
| Symbol libraries | 720 symbols loaded without Load Error after fix 11 (screenshot 10) |

**Testing status.** The fixes were verified one by one during an iterative installation on the `eSim-2.5` zip. The script in this repository (`install-eSim-26.04.sh`) contains the same edits applied on top of the repository's `install-eSim-25.04.sh`; its syntax was checked with `bash -n`.

---

## 3. Limitations and environment notes (not eSim bugs)

* **WSL update blocked.** `wsl --update` failed with `Forbidden (403)` on my network; `wsl --list --online` still worked.
* **GTK crash on WSL.** KiCad aborted with `Gtk:ERROR ... Failed to load /usr/share/icons/Adwaita/scalable/status/image-missing.svg: Loader process exited early with status '0'` until the cache folder `~/.cache/glycin/usr/libexec/glycin-loaders/2+/glycin-svg` was created (`mkdir -p`). An earlier variant of the message, `Argument list too long (os error 7)`, was caused by the long Windows `PATH` WSL adds to the environment.
* **Black symbol chooser.** Under WSL2 the KiCad symbol chooser drew a black window and KiCad closed when it was used (screenshot 10 shows the title "720 items loaded"). This looks like an OpenGL/WSLg limitation and I did not treat it as an installer problem.
* **KiCad version.** eSim 2.5 was written for KiCad 6, while Ubuntu 26.04 provides KiCad 9.0.8. The libraries load and the editor opens, but a full circuit-design/simulation workflow with KiCad 9 was not tested.

---

## 4. Files changed

| File | Change |
| --- | --- |
| `Ubuntu/install-eSim.sh` | Added `"26.04")` case |
| `Ubuntu/install-eSim-scripts/install-eSim-26.04.sh` | New script (problems 1, 2, 3, 8, 9, 11) |
| `Ubuntu/install-eSim-scripts/patches/fix1-version-case.patch` | NGHDL launcher: 26.04 → 24.04 script (problem 4) |
| `Ubuntu/install-eSim-scripts/patches/fix2-nghdl-script.patch` | NGHDL script: canberra, LLVM 18, `-std=gnu17` (problems 5, 6, 7) |
| `src/browser/Welcome.py` (master branch) | Base path fix (problem 10) |
| `Ubuntu/screenshots/` | Screenshots used in this report |

## 5. Screenshots

| # | File | Shows |
| --- | --- | --- |
| 01 | `screenshots/01-welcome-panel-blank.png` | Blank Welcome panel (problem 10) |
| 02 | `screenshots/02-welcome-py-path-diagnosis.png` | `Welcome.py` path code and the diagnosis |
| 03 | `screenshots/03-welcome-panel-fixed.png` | Welcome panel after the fix |
| 04 | `screenshots/04-nghdl-window-opens.png` | NGHDL window opens |
| 05 | `screenshots/05-kicad-to-ngspice-needs-project.png` | Normal "select a project first" message |
| 06 | `screenshots/06-kicad9-first-run-dialog.png` | KiCad 9 first-run dialog |
| 07 | `screenshots/07-global-symbol-table-dialog.png` | Global symbol library table dialog |
| 08 | `screenshots/08-kicad9-schematic-editor-opens.png` | KiCad 9 schematic editor from eSim |
| 09 | `screenshots/09-symbol-load-error-before-fix.png` | Symbol Load Error (problem 11, before) |
| 10 | `screenshots/10-choose-symbol-720-items-after-fix.png` | "720 items loaded" (problem 11, after) |
| 11 | `screenshots/11-global-footprint-table-dialog.png` | Global footprint library table dialog |

## 6. How to reproduce

```bash
unzip eSim-2.5.zip && cd eSim-2.5
./install-eSim.sh --install      # chooses install-eSim-26.04.sh on Ubuntu 26.04
```
Answer `n` to the proxy question. Open eSim with `esim`, then use **Open Project** before **Open eSchema**.
